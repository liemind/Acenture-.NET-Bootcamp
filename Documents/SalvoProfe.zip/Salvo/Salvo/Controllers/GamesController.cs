﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Salvo.Models;
using Salvo.Repositories;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Salvo.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class GamesController : ControllerBase
    {
        /// <summary>
        /// miembro privado IGameRepository
        /// </summary>
        private IGameRepository _repository;
        private IPlayerRepository _playerRepository;
        private IGamePlayerRepository _gamePlayerRepository;

        //constructor
        public GamesController(IGameRepository repository,
            IPlayerRepository playerRepository,
            IGamePlayerRepository gamePlayerRepository)
        {
            _repository = repository;
            _playerRepository = playerRepository;
            _gamePlayerRepository = gamePlayerRepository;
        }
        [HttpGet]
        [AllowAnonymous]
        public IActionResult Get()
        {
            try
            {
                GameListDTO gameList = new GameListDTO
                {
                    Email = User.FindFirst("Player") != null ? User.FindFirst("Player").Value : "Guest",
                    Games = _repository.GetAllGamesWithPlayers()
                    .Select(g => new GameDTO
                    {
                        Id = g.Id,
                        CreationDate = g.CreationDate,
                        GamePlayers = g.GamePlayers.Select(gp => new GamePlayerDTO
                        {
                            Id = gp.Id,
                            JoinDate = gp.JoinDate,
                            Player = new PlayerDTO
                            {
                                Id = gp.Player.Id,
                                Email = gp.Player.Email
                            },
                            //operador ternario
                            Point = gp.GetScore() != null ? (double?)gp.GetScore().Point : null
                        }).ToList().OrderByDescending(p=>p.Point).ToList()
                    }).ToList()
                };


                return Ok(gameList);
            }
            catch(Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }


        // GET api/<GamesController>/5
        [HttpGet("{id}")]
        public string Get(int id)
        {
            return "value";
        }

  
        [HttpPost]
        public IActionResult Post()
        {
            try
            {
                string email = User.FindFirst("Player") != null ?
                    User.FindFirst("Player").Value : "Guest";

                Player player = _playerRepository.FindByEmail(email);
                //crear entidad game player con un nuevo game
                GamePlayer gamePlayer = new GamePlayer
                {
                    PlayerId = player.Id,
                    JoinDate = DateTime.Now,
                    Game = new Game
                    {
                        CreationDate = DateTime.Now
                    }
                };
                //guardamos
                _gamePlayerRepository.Save(gamePlayer);
                //retornar
                return StatusCode(201, gamePlayer.Id);
            }
            catch(Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        [HttpPost("{id}/players")]
        public IActionResult Join(int id)
        {
            try
            {
                //email nos sirve para obtener informacion
                string email = User.FindFirst("Player") != null ?
                    User.FindFirst("Player").Value : "Guest";
                //obtuvimos player
                Player player = _playerRepository.FindByEmail(email);
                //buscar el game por id
                Game game = _repository.FindById(id);
                //si no se encuentra game
                if (game == null)
                {
                    return StatusCode(403, "No existe el juego");
                }
                //verificar player en el juego
                if (game.GamePlayers.Where(gp=>gp.Player.Id == player.Id).FirstOrDefault() != null)
                {
                    return StatusCode(403, "Ya se encuentra el jugador en el juego");
                }
                //verificar que el juego tenga un solo player
                if (game.GamePlayers.Count > 1)
                {
                    return StatusCode(403, "Juego lleno");
                }
                //crear un game player
                GamePlayer gamePlayer = new GamePlayer
                {
                    GameId = game.Id,
                    PlayerId = player.Id,
                    JoinDate = DateTime.Now
                };
                //salvamos los cambios
                _gamePlayerRepository.Save(gamePlayer);
                //retorno status
                return StatusCode(201, gamePlayer.Id);

            }
            catch(Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }


        // PUT api/<GamesController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/<GamesController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
