﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Salvo.Models;
using Salvo.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Salvo.Controllers
{
    [Route("api/gamePlayers")]
    [ApiController]
    [Authorize("PlayerOnly")]
    public class GamePlayersController : ControllerBase
    {
        private IGamePlayerRepository _repository;
        private IPlayerRepository _playerRepository;
        private IScoreRepository _scoreRepository;
        public GamePlayersController(IGamePlayerRepository repository, 
            IPlayerRepository playerRepository, 
            IScoreRepository scoreRepository)
        {
            _repository = repository;
            _playerRepository = playerRepository;
            _scoreRepository = scoreRepository;
        }

        // GET: api/<GamePlayersController>
        [HttpGet]
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET api/<GamePlayersController>/5
        [HttpGet("{id}", Name ="GetGameView")]
        public IActionResult GetGameView(int id)
        {
            try
            {
                string email = User.FindFirst("Player") != null ? User.FindFirst("Player").Value : "Guest";

                var gp = _repository.GetGamePlayerView(id);
                if (gp.Player.Email != email)
                {
                    return Forbid();
                }

                var gameView = new GameViewDTO
                {
                    Id = gp.Id,
                    CreationDate = gp.Game.CreationDate,
                    Ships = gp.Ships.Select(ship => new ShipDTO
                    {
                        Id = ship.Id,
                        Type = ship.Type,
                        Locations = ship.Locations.Select(shipLocation => new ShipLocationDTO
                        {
                            Id = shipLocation.Id,
                            Location = shipLocation.Location
                        }).ToList()
                    }).ToList(),
                    GamePlayers = gp.Game.GamePlayers.Select(gps => new GamePlayerDTO
                    {
                        Id = gps.Id,
                        JoinDate = gps.JoinDate,
                        Player = new PlayerDTO
                        {
                            Id = gps.Player.Id,
                            Email = gps.Player.Email
                        }
                    }).ToList(),
                    Salvos = gp.Game.GamePlayers.SelectMany(gps => gps.Salvos.Select(salvo => new SalvoDTO
                    {
                        Id = salvo.Id,
                        Turn = salvo.Turn,
                        Player = new PlayerDTO
                        {
                            Id = gps.Player.Id,
                            Email = gps.Player.Email
                        },
                        Locations = salvo.Locations.Select(salvoLocation => new SalvoLocationDTO
                        {
                            Id = salvoLocation.Id,
                            Location = salvoLocation.Location
                        }).ToList()
                    })).ToList(),
                    //nuevos metodos
                    //hits
                    Hits = gp.GetHits(),
                    HitsOpponent = gp.GetOpponent()?.GetHits(),
                    //sunks
                    Sunks = gp.GetSunks(),
                    SunksOpponent = gp.GetOpponent()?.GetSunks(),
                    GameState = Enum.GetName(typeof(GameState), gp.GetGameState())
                };

                return Ok(gameView);
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        //api/GamePlayers/id/ships
        [HttpPost("{id}/ships")]
        public IActionResult Post(int id, [FromBody] List<ShipDTO> ships)
        {
            try
            {
                //email del auntentificado
                string email = User.FindFirst("Player") != null
                    ? User.FindFirst("Player").Value : "Guest";
                //buscar el player por el email
                Player player = _playerRepository.FindByEmail(email);
                //buscar el game player por id
                GamePlayer gamePlayer = _repository.FindById(id);
                //no existe game player con id indicado
                //no existe cuando gamePlayer es null
                if (gamePlayer == null)
                {
                    return StatusCode(403, "No existe el juego");
                }
                //usuario autenticado no se encuentra en el juego
                //se compara player.Id vs gamePlayer.Player.Id
                if (gamePlayer.Player.Id != player.Id)
                {
                    return StatusCode(403, "El usuario no se encuentra en el juego");
                }
                //para poder validar si los barcos estan posicionados
                //el gameplayer debería tener 5 ships
                if (gamePlayer.Ships.Count == 5)
                {
                    return StatusCode(403, "Ya se han posicionado los barcos");
                }
                //insertar los barcos al gameplayer
                gamePlayer.Ships = ships.Select(sh => new Ship
                {
                    GamePlayerId = gamePlayer.Id,
                    Type = sh.Type,
                    Locations = sh.Locations.Select(loc => new ShipLocation
                    {
                        ShipId = sh.Id,
                        Location = loc.Location
                    }).ToList()
                }).ToList();
                //debemos actualizar la informacion
                _repository.Save(gamePlayer);
                //devolvemos
                return StatusCode(201);



            }
            catch(Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        //api/GamePlayers/id/salvos
        [HttpPost("{id}/salvos")]
        public IActionResult Post(int id, [FromBody] SalvoDTO salvo)
        {
            try
            {
                //variables para controlar el turno
                int playerTurn = 0;
                int opponentTurn = 0;
                //obtengo email logeado
                string email = User.FindFirst("Player") != null ? User.FindFirst("Player").Value : "Guest";
                // obtengo player por id
                Player player = _playerRepository.FindByEmail(email);
                //busco el juego por id
                GamePlayer gamePlayer = _repository.FindById(id);
                // verifico si existe el juego
                if (gamePlayer == null)
                {
                    return StatusCode(403, "No existe el juego");
                }
                //usuario no se encuentra en el juegoo actual
                if (gamePlayer.Player.Id != player.Id)
                {
                    return StatusCode(403, "El usuario no se encuentra en el juego");
                }
                //obtener oponente
                GamePlayer oponenteGamePlayer = gamePlayer.GetOpponent();
                
                //verificar si oponente existe
                if (oponenteGamePlayer == null)
                {
                    return StatusCode(403, "No se encontro oponente");
                }
                //oponenteGamePlayer = _repository.FindById((int)oponenteGamePlayer.Id);
                //verificar si estan posicionados los barcos

                /////////PENDIENTE//////////////////////////
                if (oponenteGamePlayer != null)
                {
                    //por alguna razón opponentGamePlayer.Ships no me trae los datos actualizados
                    //pero no importa ocupamos el repositorio para traernos los ships
                    //tenemos el oponenteGamePlayer.Id
                    List<Ship> shipsOponente = _repository.FindById((int)oponenteGamePlayer.Id).Ships.ToList();
                    if (shipsOponente == null || shipsOponente.Count == 0)
                    {
                        return StatusCode(403, "Tu oponente no ha posicionado sus barcos!!!");
                    }
                    
                }

                //aca deberiamos agregar las otras validaciones
                //antes de los turnos verificar si el juego ya terminó
                GameState gameState = gamePlayer.GetGameState();
                if (gameState == GameState.LOSS || gameState == GameState.WIN
                    || gameState == GameState.TIE)
                {
                    return StatusCode(403, "El juego ya terminó!!!");
                }

                //turno jugador actual
                playerTurn = gamePlayer.Salvos != null ? gamePlayer.Salvos.Count() + 1 : 1;
                //turno Oponente
                opponentTurn = oponenteGamePlayer.Salvos != null ? oponenteGamePlayer.Salvos.Count() : 0;
                if (gamePlayer.JoinDate < oponenteGamePlayer.JoinDate && (playerTurn - opponentTurn) != 1)
                {
                    return StatusCode(403, "No se puede adelantar al turno");
                }
                if (gamePlayer.JoinDate > oponenteGamePlayer.JoinDate && (playerTurn - opponentTurn) != 0)
                {
                    return StatusCode(403, "No se puede adelantar al turno");
                }
                gamePlayer.Salvos.Add(new Models.Salvo
                {
                    GamePlayerId = gamePlayer.Id,
                    Turn = playerTurn,
                    Locations = salvo.Locations.Select(location => new SalvoLocation
                    {
                        SalvoId = salvo.Id,
                        Location = location.Location
                    }).ToList()

                });

                //guardamops y actualizamos
                _repository.Save(gamePlayer);
                //ACA GUARDAR EL SCORE
                gameState = gamePlayer.GetGameState();
                //empezamos!!!
                if (gameState == GameState.WIN)
                {
                    #region win
                    Score score = new Score
                    {
                        FinishDate = DateTime.Now,
                        GameId = gamePlayer.GameId,
                        PlayerId = gamePlayer.PlayerId,
                        Point = 1
                    };
                    _scoreRepository.Save(score);

                    Score scoreOpponent = new Score
                    {
                        FinishDate = DateTime.Now,
                        GameId = gamePlayer.GameId,
                        PlayerId = oponenteGamePlayer.PlayerId,
                        Point = 0
                    };
                    _scoreRepository.Save(scoreOpponent);
                    #endregion
                }
                else if (gameState == GameState.LOSS)
                {
                    #region loss
                    Score score = new Score
                    {
                        FinishDate = DateTime.Now,
                        GameId = gamePlayer.GameId,
                        PlayerId = gamePlayer.PlayerId,
                        Point = 0
                    };
                    _scoreRepository.Save(score);

                    Score scoreOpponent = new Score
                    {
                        FinishDate = DateTime.Now,
                        GameId = gamePlayer.GameId,
                        PlayerId = oponenteGamePlayer.PlayerId,
                        Point = 1
                    };
                    _scoreRepository.Save(scoreOpponent);
                    #endregion
                }
                else if (gameState == GameState.TIE)
                {
                    Score score = new Score
                    {
                        FinishDate = DateTime.Now,
                        GameId = gamePlayer.GameId,
                        PlayerId = gamePlayer.PlayerId,
                        Point = 0.5
                    };
                    _scoreRepository.Save(score);

                    Score scoreOpponent = new Score
                    {
                        FinishDate = DateTime.Now,
                        GameId = gamePlayer.GameId,
                        PlayerId = oponenteGamePlayer.PlayerId,
                        Point = 0.5
                    };

                    _scoreRepository.Save(scoreOpponent);
                }

                return StatusCode(201);
            }
            catch(Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        // PUT api/<GamePlayersController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/<GamePlayersController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
