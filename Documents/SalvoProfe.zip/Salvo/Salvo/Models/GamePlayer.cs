﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Salvo.Models
{
    public class GamePlayer
    {
        //los propios de la tabla Game player
        public long Id { get; set; }
        public DateTime JoinDate { get; set; }
        //foraneas
        //player
        public long PlayerId { get; set; }
        public Player Player { get; set; }
        //games
        public long GameId { get; set; }
        public Game Game { get; set; }
        //relacion con Ship
        public ICollection<Ship> Ships { get; set; }
        //agregar los salvos
        public ICollection<Salvo> Salvos { get; set; }
        //get score
        public Score GetScore()
        {
            return Player.GetScore(Game);
        }
        //metodo es para obtener los oponentes
        public GamePlayer GetOpponent()
        {
            return Game.GamePlayers.FirstOrDefault(gp => gp.Id != Id);
        }
        //metodo get hits
        public ICollection<SalvoHitDTO> GetHits()
        {
            return Salvos.Select(salvo => new SalvoHitDTO
            {
                Turn = salvo.Turn,
                Hits = GetOpponent()?.Ships.Select(ship => new ShipHitDTO
                {
                    Type = ship.Type,
                    Hits = salvo.Locations
                            .Where(salvoLocation => ship.Locations.Any(shipLocation => shipLocation.Location == salvoLocation.Location))
                            .Select(salvoLocation => salvoLocation.Location).ToList()
                }).ToList()
            }).ToList();
        
        }
        //get sunks
        public ICollection<string> GetSunks()
        {
            //identificar el ultimo turno
            int lastTurn = Salvos.Count;
            //obtenemos un listado de string de salvo location
            //deberá entregar todos aquellos que sean ultimo turno <= al turno del salvo
            List<string> salvoLocations = GetOpponent()?.Salvos
                                            .Where(salvo => salvo.Turn <= lastTurn)
                                            .SelectMany(salvo => salvo.Locations.Select(location => location.Location)).ToList();

            return Ships?.Where(ship => ship.Locations.Select(shipLocation => shipLocation.Location)
                        .All(salvoLocation => salvoLocations != null ? salvoLocations.Any(shipLocation => shipLocation == salvoLocation) : false))
                        .Select(ship => ship.Type).ToList();

        }
        //retorna GameState
        public GameState GetGameState()
        {
            //inicializar en una variable el primer estado
            GameState gameState = GameState.ENTER_SALVO;
            //si los barcos son nulos o count 0
            //dejamos en place_ships ya que no ha posicionado los barcos
            if (Ships == null || Ships?.Count() == 0)
            {
                gameState = GameState.PLACE_SHIPS;
            }
            ///vamos a evaluar si el oponente es nulo
            else if(GetOpponent() == null)
            {
                //salvos count
                if (Salvos != null && Salvos?.Count() > 0)
                {
                    gameState = GameState.WAIT;
                }
            }
            //si no ocurren ninguna de las condiciones anteriores del if y else if
            //va a entrar a este bloque (else)
            else
            {
                //obtenemos nuestro oponente
                GamePlayer opponent = GetOpponent();
                //ahora debemos determinar el turno
                int turn = Salvos != null ? Salvos.Count() : 0;
                //determinamos el turno del oponente
                int opponentTurn = opponent.Salvos != null ? opponent.Salvos.Count() : 0;
                //si mi turno es mayor al del oponente debemos esperar
                if (turn > opponentTurn)
                {
                    gameState = GameState.WAIT;
                }
                else if (turn == opponentTurn && turn != 0)
                {
                    //hundidos sunks
                    //mis hundidos
                    int playerSunks = GetSunks().Count();
                    //hundidos del oponente
                    int opponenSunks = opponent.GetSunks().Count();
                    //con esto nosotros evaluamos si existe un empate
                    if (playerSunks == Ships.Count() && 
                        opponenSunks == opponent.Ships.Count())
                    {
                        gameState = GameState.TIE;
                    }
                    //para evaluar si perdió
                    else if (playerSunks == Ships.Count())
                    {
                        gameState = GameState.LOSS;
                    }
                    //para evaluar el que gano
                    else if (opponenSunks == opponent.Ships.Count())
                    {
                        gameState = GameState.WIN;
                    }
                }

            }



            return gameState;
        }
    }
}
